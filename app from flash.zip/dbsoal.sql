-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2020 at 03:59 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsoal`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftarsoal`
--

CREATE TABLE `daftarsoal` (
  `no` int(2) NOT NULL,
  `pertanyaan` text NOT NULL,
  `opsiA` varchar(20) NOT NULL,
  `opsiB` varchar(20) NOT NULL,
  `opsiC` varchar(20) NOT NULL,
  `opsiD` varchar(20) NOT NULL,
  `jawaban` varchar(20) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daftarsoal`
--

INSERT INTO `daftarsoal` (`no`, `pertanyaan`, `opsiA`, `opsiB`, `opsiC`, `opsiD`, `jawaban`, `status`) VALUES
(1, 'sel-sel dan banyak struktur biologis lainnya yang bertanggung jawab atas imunitas, yaitu pertahanan pada organisme untuk melindungi tubuh dari pengaruh biologis luar dengan mengenali dan membunuh patogen disebut', 'sistem imun', 'pencernaan', 'metamorfosis', 'kanker', 'sistem imun', 0),
(2, 'bentuk pertahanan awal yang melibatkan penghalang permukaan, reaksi peradangan, sistem komplemen, dan komponen seluler disebut sistem imun ..', 'bawaan', 'adaptif', 'imunode', 'ulang', 'bawaan', 0),
(3, 'sistem imun menjadi hiperaktif menyerang jaringan normal seakan-akan jaringan tersebut merupakan benda asing disebut penyakit...', 'ksnker', 'autoimun', 'imperten', 'cacar', 'autoimun', 0),
(4, 'sistem yang berevolusi pada vertebrata awal dan membuat adanya respons imun yang lebih kuat serta terbentuknya memori imunologi disebut ..', 'origin', 'imperten', 'bawaan', 'adaptif', 'adaptif', 0),
(5, 'Gangguan pada sistem imun, kecuali ..', 'cacar', 'inflamasi', 'imunodefisiensi', 'autoimun', 'cacar', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftarsoal`
--
ALTER TABLE `daftarsoal`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftarsoal`
--
ALTER TABLE `daftarsoal`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
